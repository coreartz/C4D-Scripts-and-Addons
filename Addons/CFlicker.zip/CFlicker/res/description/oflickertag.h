#ifndef _OFlickerTag_H_
#define _OFlickerTag_H_

enum
{
    CLIGHT_STRENGTH     = 1000,
    CLIGHT_SEED,
    CFLICKER_LIGHT,
    CFLICKER_PROB,
    CFLICKER_LENGTH,
    CFLICKER_LENGTH_VAR,
}

#endif
