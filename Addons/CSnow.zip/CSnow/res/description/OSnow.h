#pragma once

enum {

    OSnow = 1000,

    SNOW_THICKNESS,
    SNOW_VIEWPORT,
    SNOW_RENDER,

    SNOW_POINTS,
    SNOW_POINT_SCALE,
    SNOW_ANGLE,
    SNOW_SEED,

};