#ifndef _OSnapTag_H_
#define _OSnapTag_H_

enum
{
    CSNAP_HEIGTH     = 1000,
}

#endif
